# -*- coding: utf-8 -*-
#---------------------------------------------------------------------------
# Copyright 2018 VMware, Inc.  All rights reserved.

# AUTO GENERATED FILE -- DO NOT MODIFY!
#
# vAPI skeleton file for package com.vmware.vapi.std.activation.
#---------------------------------------------------------------------------

__author__ = 'VMware, Inc.'
__docformat__ = 'restructuredtext en'

import sys

from vmware.vapi.bindings import type
from vmware.vapi.bindings.converter import TypeConverter
from vmware.vapi.bindings.enum import Enum
from vmware.vapi.bindings.error import VapiError
from vmware.vapi.bindings.skeleton import VapiInterface, ApiInterfaceSkeleton
from vmware.vapi.bindings.common import raise_core_exception
from vmware.vapi.bindings.struct import VapiStruct
from vmware.vapi.data.validator import (UnionValidator, HasFieldsOfValidator)
from vmware.vapi.lib.constants import TaskType



class ActivationManager(VapiInterface):
    """
    **WARNING:** Use only as a sample. The API is experimental and subject to
    change in future versions. 
    
     Activation tracking/management service. 
    
     An activation describes a method invocation in the runtime.
    """


    def __init__(self, error_types=None):
        VapiInterface.__init__(self, ActivationManagerSkeleton,
                               error_types=error_types)


    def cancel(self,
               activation_id,
               ):
        """
        Asks for cancellation of a running activation. Whether or not the
        cancellation request will have any effect depends on the implementation
        of the method that has to be canceled.

        :type  activation_id: :class:`str`
        :param activation_id: activation identifier
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound` 
            there is no activation with the specified id
        """
        raise NotImplementedError('Method %s in class %s is not implemented' %
                                  ('cancel', 'ActivationManager'))




class ActivationManagerSkeleton(ApiInterfaceSkeleton):
    def __init__(self, impl, error_types):

        # properties for cancel operation
        cancel_input_type = type.StructType('operation-input', {
            'activation_id': type.StringType(),
        })
        cancel_error_list = [
            type.ReferenceType('com.vmware.vapi.std.errors_provider', 'NotFound'),
        ]
        cancel_input_value_validator_list = [
        ]
        cancel_output_validator_list = [
        ]

        operations = {
            'cancel': {
                'input_type': cancel_input_type,
                'output_type': type.VoidType(),
                'errors': cancel_error_list,
                'input_value_validator_list': cancel_input_value_validator_list,
                'output_validator_list': cancel_output_validator_list,
                'task_type': TaskType.NONE,
            },
        }
        ApiInterfaceSkeleton.__init__(self,
                                      iface_name='com.vmware.vapi.std.activation.activation_manager',
                                      impl=impl,
                                      operations=operations,
                                      error_types=error_types)


