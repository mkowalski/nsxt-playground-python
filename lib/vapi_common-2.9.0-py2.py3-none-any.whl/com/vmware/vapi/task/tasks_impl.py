"""
Tasks Service Implementation
"""

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2017 VMware, Inc.  All rights reserved. -- VMware Confidential'  # pylint: disable=line-too-long

from com.vmware.cis_provider import Tasks
from com.vmware.cis.task_provider import Info
from vmware.vapi.bindings.converter import TypeConverter
from vmware.vapi.task.task_manager_impl import get_task_manager
from vmware.vapi.lib.log import get_vapi_logger
from vmware.vapi.stdlib.provider.factories import MessageFactory, ErrorFactory

messages = {
    'task.no_filter_spec':
        'No filter specification provided',
    'task.not_found':
        'Task with id "%s" was not found',
    'task.not_implemented':
        'The API is not implemented',
}
message_factory = MessageFactory(messages)
logger = get_vapi_logger(__name__)


class TasksImpl(Tasks):
    """
    A basic ``Tasks`` class provides methods for managing the task related to a
    long running operation.
    """
    def __init__(self, task_manager=None):
        Tasks.__init__(self)
        self.task_manager = get_task_manager()

    def get(self,
            task,
            spec=None,
            ):
        """
        Returns information about a task.

        :type  task: :class:`str`
        :param task: Task identifier.
            The parameter must be an identifier for the resource type:
            `com.vmware.cis.Tasks`.
        :type  spec: :class:`Tasks.GetSpec` or `None`
        :param spec: Specification on what to get for a task.
            If None, use default values in the GetSpec.
        :rtype: :class:`com.vmware.cis.task_provider.Info`
        :return: Information about the specified task.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Error`
            if the system reports an error while responding to the request.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            if the task is not found.
        :raise: :class:
            `com.vmware.vapi.std.errors_provider.ResourceInaccessible` if the
             task's state cannot be accessed.
        :raise: :class:`com.vmware.vapi.std.errors_provider.ServiceUnavailable`
            if the system is unable to communicate with a service to complete
            the request.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Unauthenticated`
            if the user can not be authenticated.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Unauthorized`
            if the user doesn't have the required privileges.
        """
        try:
            info_value = self.task_manager.get_info(task)
            info = TypeConverter.convert_to_python(info_value,
                                                   Info.get_binding_type())
            if spec is not None:
                if spec.exclude_result:
                    info.result = None
        except KeyError:
            msg = message_factory.get_message('task.not_found',
                                              task)
            logger.error(msg)
            raise ErrorFactory.new_not_found(messages=[msg])

        return info

    def list(self,
             filter_spec=None,
             result_spec=None
             ):
        """
        Returns information for a list of tasks.

        :type  filter_spec: :class:`Tasks.FilterSpec`
        :param filter_spec: Filter the results when listing tasks.
            Currently required. In the future, if None, use default values in
            the GetSpec.
        :type  result_spec: :class:`Tasks.GetSpec` or ``None``
        :param result_spec: Specification on what to get for a task.
            If None, use default values in the GetSpec.
        :rtype: :class:`dict` of :class:`str` and
                :class:`com.vmware.cis.task_provider.Info`
        :return: Map of task identifier to information about the task.
            The key in the return value :class:`dict` will be an identifier for
            the resource type: `com.vmware.cis.Tasks`.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Error`
            if the system reports an error while responding to the request.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            if the task is not found.
        :raise: :class:
            `com.vmware.vapi.std.errors_provider.ResourceInaccessible` if the
             task's state cannot be accessed.
        :raise: :class:`com.vmware.vapi.std.errors_provider.ServiceUnavailable`
            if the system is unable to communicate with a service to complete
            the request.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Unauthenticated`
            if the user can not be authenticated.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Unauthorized`
            if the user doesn't have the required privileges.
        """
        if filter_spec is None:
            msg = message_factory.get_message('task.no_filter_spec')
            logger.error(msg)
            raise ErrorFactory.new_invalid_argument(messages=[msg])

        info_map = {}
        for task in filter_spec.tasks:
            try:
                info_value = self.task_manager.get_info(task)
                info = TypeConverter.convert_to_python(info_value,
                                                       Info.get_binding_type())
            except KeyError:
                continue
            if filter_spec.status is not None and info.status not in \
                    filter_spec.status:
                continue
            if filter_spec.targets is not None and info.target not in \
                    filter_spec.targets:
                continue
            if filter_spec.users is not None and info.user not in \
                    filter_spec.users:
                continue
            if result_spec is not None:
                if result_spec.exclude_result:
                    info.result = None

            info_map.setdefault(task, info)

        return info_map

    def cancel(self,
               task,
               ):
        """
        Cancel a running task. This is the best effort. Task cannot be
        cancelled anymore once it reaches certain stage.

        :type  task: :class:`str`
        :param task: Task identifier.
            The parameter must be an identifier for the resource type:
            ``com.vmware.cis.Task``.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Error`
            if the system reports an error while responding to the request.
        :raise: :class:
            `com.vmware.vapi.std.errors_provider.NotAllowedInCurrentState` if
             the task is already canceled or completed.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            if the task is not found.
        :raise: :class:
            `com.vmware.vapi.std.errors_provider.ResourceInaccessible` if the
             task's state cannot be accessed.
        :raise: :class:`com.vmware.vapi.std.errors_provider.ServiceUnavailable`
            if the system is unable to communicate with a service to complete
            the request.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Unauthenticated`
            if the user can not be authenticated.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Unauthorized`
            if the user doesn't have the required privileges.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Unsupported`
            if the task is not cancelable.
        """
        msg = message_factory.get_message('task.not_implemented')
        logger.error(msg)
        raise ErrorFactory.new_error(messages=[msg])


def register_instance():
    """
    Specify the instances that should be
    registered with the api provider
    """
    return [
        TasksImpl(),
    ]
