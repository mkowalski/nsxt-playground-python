"""
Implementation of routing metadata service
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2015-2017 VMware, Inc.  All rights reserved. -- VMware Confidential'  # pylint: disable=line-too-long
__docformat__ = 'restructuredtext en'

import re
import six

from com.vmware.vapi.metadata.routing_provider import (
    Package, Component, Service, Source, ComponentData,
    PackageInfo, OperationInfo, RoutingInfo, ComponentInfo,
    ServiceInfo)
from com.vmware.vapi.metadata.routing.service_provider import Operation
from com.vmware.vapi.metadata.util.maps import get_routing_maps
from com.vmware.vapi.metadata.util.sources_mixin import SourceMixin
from vmware.vapi.lib.log import get_vapi_logger
from vmware.vapi.stdlib.provider.factories import MessageFactory, ErrorFactory

messages = {
    'metadata.routing.component.not_found':
        'Component %s does not have any routing information',
    'metadata.routing.package.not_found':
        'Package %s does not have any routing information',
    'metadata.routing.service.not_found':
        'Service %s does not have any routing information',
    'metadata.routing.operatilon.not_found':
        'Operation %s in Service %s does not have any routing information',
    'metadata.routing.format.invalid':
    'Metadata is invalid. It should be either parametrized IDROUTE(path.to.param) or non-parametrized FIRSTIDROUTE',
    'metadata.routing.strategy.invalid':
    'Routing strategy is invalid. On a method level, it should be either ' +
    'HINTS(create|delete|move), any parametrized strategy or any ' +
    'non-parametrized strategy with or without HINTS specified'
}
message_factory = MessageFactory(messages)
logger = get_vapi_logger(__name__)
ROUTING = 'routing'
PACKAGES = 'packages'
SERVICES = 'services'
TYPES = 'types'
ID_TYPES_PACKAGE = 'com.vmware.vapi.routing.idTypes'
NAME = 'name'


class OperationImpl(Operation):
    """
    Operations to retrieve routing information in a vAPI operation
    An operation is said to contain routing information if on package,
    or service level is defined the routing strategy, or explicitly in a
    single method.
    """
    def __init__(self, maps):
        """
        Initialize OperationImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Operation.__init__(self)
        self._maps = maps

    def list(self, service_id):
        """
        Get the IDs of all the vAPI operations in the given service that contain
        routing information

        :type  service_id: :class:`str`
        :param service_id: Identifier of the service.
        :rtype: :class:`list` of :class:`str`
        :return: list of operation identifiers.
        :raise:: :class:`com.vmware.vapi.std.errors_provider.NotFound` If the service identifier does not exist.
        """
        if service_id not in self._maps.service_info:
            msg = message_factory.get_message(
                'metadata.routing.service.not_found',
                service_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return [operation_name
                for service_name, operation_name in self._maps.operation_info.keys()
                if service_id == service_name]

    def get(self, service_id, operation_id):
        """
        Get information about a vAPI operation that contains routing information

        :type service_id: :class:`str`
        @arg  service_id: Service identifier
        :type operation_id: :class:`str`
        @arg  operation_id: Operation identifier
        :rtype: :class:`com.vmware.vapi.metadata.routing_provider.OperationInfo`
        :return: metamodel info of the vAPI operation
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`: If the service name does
            not exist or specified operationName does not exist in the interface
        """
        operation_info = self._maps.operation_info.get((service_id,
                                                        operation_id))
        if operation_info is None:
            msg = message_factory.get_message(
                'metadata.routing.operation.not_found',
                operation_id, service_id)
            logger.error(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return operation_info


class PackageImpl(Package):
    """
    Operations to retrieve routing information in a vAPI package
    A Package is said to contain routing information if there is a default
    routing strategy assigned to all operations within a package
    """
    def __init__(self, maps):
        """
        Initialize PackageImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Package.__init__(self)
        self._maps = maps

    def list(self):
        """
        List of all vAPI packages that have routing information

        :rtype: :class:`list` of :class:`str`
        :return: list of fully qualified package names
        """
        return self._maps.package_info.keys()

    def get(self, package_id):
        """
        Get the routing information for a vAPI package

        :type  package_id: :class:`str`
        :param package_id: fully qualified package identifier.
        :rtype: :class:`com.vmware.vapi.metadata.routing_provider.PackageInfo`
        :return: routing information for the vAPI package.
        :raise:: :class:`com.vmware.vapi.std.errors_provider.NotFound` If the package identifier does not exist.
        """
        package_info = self._maps.package_info.get(package_id)
        if package_info is None:
            msg = message_factory.get_message(
                'metadata.routing.package.not_found',
                package_id)
            logger.error(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return package_info


class ComponentImpl(Component):
    """
    Operations to retrieve routing information in a vAPI component
    A Component is said to contain routing information if any of its packages
    contain such information.
    """
    def __init__(self, maps):
        """
        Initialize ComponentImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Component.__init__(self)
        self._maps = maps

    def list(self):
        """
        List all the vAPI components that contain operations which have routing
        information.

        :rtype: :class:`list` of :class:`str`
        :return: list of fully qualified component names
        """
        return self._maps.component_info.keys()

    def get(self, component_id):
        """
        Get the routing information for a vAPI component

        :type component_id: :class:`str`
        :param component_id: Id of a component.
        :rtype: :class:`com.vmware.vapi.metadata.routing_provider.ComponentInfo`
        :return: routing information for the vAPI component
        :raise: :class:`vmware.vapi.bindings.error.NotFound`: If the component id does not exist
        """
        component_info = self._maps.component_info.get(component_id)
        if component_info is None:
            msg = message_factory.get_message(
                'metadata.routing.component.not_found',
                component_id)
            logger.error(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return ComponentData(info=component_info,
                             fingerprint=self.fingerprint(component_id=component_id))

    def fingerprint(self, component_id):
        """
        Fingerprint of all routing metadata for a vAPI component on the server

        :type component_id: :class:`str`
   :param component_id: Fully qualified component id.
        :rtype: :class:`str`
        :return: fingerprint of routing metadata for a vAPI component
        :raise: :class:`vmware.vapi.bindings.error.NotFound`: If the component id does not exist
        """
        fingerprint = self._maps.component_fingerprints.get(component_id)
        if fingerprint is None:
            msg = message_factory.get_message(
                'metadata.routing.component.not_found',
                component_id)
            logger.error(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return fingerprint


class ServiceImpl(Service):
    """
    Operations to retrieve routing information of a vAPI service
    """
    def __init__(self, maps):
        """
        Initialize ServiceImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Service.__init__(self)
        self._maps = maps

    def list(self):
        """
        Get list of all vAPI services that have operations with routing information

        :rtype: :class:`list` of :class:`str`
        :return: list of fully qualified service names
        """
        return self._maps.service_info.keys()

    def get(self, service_id):
        """
        Get the routing information for a vAPI service

        :type service_id: :class:`str`
        :param service_id: :class:`str` fully qualified service name
        :rtype: :class:`com.vmware.vapi.metadata.routing_provider.ServiceInfo`
        :return: identifier information for the vAPI service
        :raise: :class:`vmware.vapi.bindings.error.NotFound`: If the service id does not exist
        """
        service_info = self._maps.service_info.get(service_id)
        if service_info is None:
            msg = message_factory.get_message(
                'metadata.routing.service.not_found',
                service_id)
            logger.error(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return service_info


class SourceImpl(SourceMixin, Source):
    """
    Operations to manage the metadata sources for routing information
    """

    ROUTING_REGEX = re.compile(r"^([a-zA-Z]+)(\((.*?)\))?(,HINTS\((.*?)\))?$")
    PLAIN_ROUTING_STRATEGIES = ['FIRSTIDROUTE', 'STANDARD', 'LOCAL', 'BROADCAST']
    PARAM_ROUTING_STRATEGIES = ['IDROUTE']
    SPECIAL = [",", ")", "("]
    OPENING_PARENTHESIS = "("
    CLOSING_PARENTHESIS = ")"
    HINTS = 'HINTS'
    HINTS_SEPARATOR = ','

    def __init__(self, maps, cfg):
        """
        Initialize SourceImpl with routing metadata.
        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Source.__init__(self)
        SourceMixin.__init__(self, maps, ROUTING, cfg)

    @staticmethod
    def _parse_json_operation_metadata(operation_metadata):
        """
        Parse operation metadata from json object

        :type  operation_metadata: :class:`dict`
        :param operation_metadata: Operation metadata
        :rtype: :class:`dict`
        :return: Operation metadata after processing
        """
        operation_data = {}
        for operation_name, routing_strategy in six.iteritems(operation_metadata):
            routing_info = SourceImpl._parse_routing_info(routing_strategy)
            operation_info = OperationInfo(routing_info=routing_info)

            operation_data[operation_name] = operation_info
        return operation_data

    def _parse_json_package_metadata(self, package_metadata):
        """
        Parse package metadata from json object

        :type  package_metadata: :class:`dict`
        :param package_metadata: Operation metadata
        :rtype: :class:`dict`
        :return: Package metadata after processing
        """
        package_map = {}
        if package_metadata:
            for package_name, routing_strategy in six.iteritems(package_metadata):
                routing_info = self._parse_routing_info(routing_strategy)
                package_info = PackageInfo(routing_info=routing_info, services={})
                package_map[package_name] = package_info
        return package_map

    def _parse_json_service_metadata(self, service_metadata):
        """
        Parse service metadata from json object

        :type  service_metadata: :class:`dict`
        :param service_metadata: Operation metadata
        :rtype: :class:`dict`
        :return: Service metadata after processing
        """
        service_map = {}
        if service_metadata:
            for service_name, routing_strategy in six.iteritems(service_metadata):
                routing_info = self._parse_routing_info(routing_strategy)
                service_info = ServiceInfo(routing_info=routing_info, operations={})
                service_map[service_name] = service_info
        return service_map

    @staticmethod
    def _parse_json_id_types_metadata(id_types_metadata):
        """
        Parse id types metadata from json object

        :type  id_types_metadata: :class:`dict`
        :param id_types_metadata: Id Types metadata
        :rtype: :class:`dict`
        :return: ID Types metadata after processing
        """
        id_types_map = {}
        if id_types_metadata:
            for id_type_name, id_type in six.iteritems(id_types_metadata):
                id_types_map[id_type_name] = id_type
        return id_types_map

    @staticmethod
    def _parse_routing_info(routing_strategy):
        """
        Based on routing strategy this method forms RoutingInfo object
        There are three possibilities - it is non-param routing strategy and
        the seconds is that it is parametrized routing strategy
        the third is that this method inherits its routing strategy from
        a parent and here we specified only HINTS(create|delete|move)
        """
        match = SourceImpl.ROUTING_REGEX.match(routing_strategy)
        if match is not None:
            r_strategy = match.group(1)
            r_path = match.group(3)
            op_hints = match.group(5)
            hints_list = SourceImpl._process_op_hints(op_hints)
            if SourceImpl.HINTS == r_strategy:
                return RoutingInfo(routing_strategy='', routing_path='', operation_hints=hints_list, id_types={})
            else:
                return SourceImpl._parse_routing_strategy(r_strategy, r_path, hints_list)
        else:
            msg = message_factory.get_message('metadata.routing.strategy.invalid')
            logger.error(msg)
            raise ErrorFactory.new_invalid_argument(messages=[msg])

    @staticmethod
    def _process_op_hints(op_hints):
        """
        Returns the value of the operation hint weather it is present or not.
        """
        if op_hints is None:
            return []
        else:
            return SourceImpl._split_hints(op_hints)

    @staticmethod
    def _split_hints(op_hints):
        """
        This method splits hints by ',' and by semantic meaning. E.g. if we have
        delete,create($ret,cluster_id). The resulting list will be ['delete', 'create($ret,cluster_id)']
        @var word: Is a single hint which will be added to the array.
        @var hints_arr: The resulting array of simple hint definitions.
        @var level: Shows weather open parenthesis is reached or not.
        :return: Array of hints.
        """
        word = ""
        hints_arr = []
        level = 0
        for i in range(0, len(op_hints)):
            current_character = op_hints[i]
            if current_character in SourceImpl.SPECIAL:
                if current_character == SourceImpl.OPENING_PARENTHESIS:
                    level = level + 1
                if current_character == SourceImpl.CLOSING_PARENTHESIS:
                    level = level - 1
                    word += current_character
                else:
                    if level > 0:
                        word += current_character
                if level == 0:
                    if word is not "":
                        hints_arr.append(word)
                        word = ""
            else:
                word += current_character
        if word is not "":
            hints_arr.append(word)
        return hints_arr

    @staticmethod
    def _parse_routing_strategy(r_strategy, r_path, hints_list):
        """
        This method parses the input routing strategy with or without HINTS specified
        """
        if r_strategy in SourceImpl.PLAIN_ROUTING_STRATEGIES:
            if r_path is None:
                return RoutingInfo(routing_strategy=r_strategy, routing_path='',
                                   operation_hints=hints_list, id_types={})
            else:
                msg = message_factory.get_message('metadata.routing.format.invalid')
                logger.error(msg)
                raise ErrorFactory.new_invalid_argument(messages=[msg])

        if r_strategy in SourceImpl.PARAM_ROUTING_STRATEGIES:
            if r_path is None:
                msg = message_factory.get_message('metadata.routing.format.invalid')
                logger.error(msg)
                raise ErrorFactory.new_invalid_argument(messages=[msg])
            else:
                return RoutingInfo(routing_strategy=r_strategy, routing_path=r_path,
                                   operation_hints=hints_list, id_types={})

        msg = message_factory.get_message('metadata.routing.strategy.invalid')
        logger.error(msg)
        raise ErrorFactory.new_invalid_argument(messages=[msg])

    def _parse_json_component_info(self, id_, component_metadata):
        """
        Parse routing metadata from a config file

        :type  id_: :class:`str`
        :param id_: Source identifier
        :type  component_name: :class:`str`
        :param component_name: Component name
        :type  component_metadata: :class:`ConfigParser`
        :param component_metadata: ConfigParser object of the routing
            definition file
        """
        # Process service specific routing
        metadata_keys = list(component_metadata.keys())
        metadata_keys.remove(NAME)

        if not metadata_keys:
            # There is no routing metadata present for this
            # component in the json file
            return

        packages = component_metadata.get(PACKAGES)
        package_map = self._parse_json_package_metadata(packages)
        metadata_keys.remove(PACKAGES)

        services = component_metadata.get(SERVICES)
        service_map = self._parse_json_service_metadata(services)
        metadata_keys.remove(SERVICES)

        id_types = component_metadata.get(TYPES)
        id_types_map = SourceImpl._parse_json_id_types_metadata(id_types)
        package_map = SourceImpl._add_id_types_package(package_map, id_types_map)
        if id_types:
            metadata_keys.remove(TYPES)
        empty_routing_info = RoutingInfo(routing_strategy='', routing_path='', operation_hints=[], id_types={})
        for service_name in metadata_keys:
            tokens = service_name.split('.')
            package_name = '.'.join(tokens[:-1])
            package_info = package_map.get(package_name,
                                           PackageInfo(routing_info=empty_routing_info, services={}))

            # Process routing for operations
            service_metadata = component_metadata.get(service_name)
            operation_data = SourceImpl._parse_json_operation_metadata(
                service_metadata)

            service_info = service_map.get(service_name, ServiceInfo(routing_info=empty_routing_info, operations={}))
            for operation_name, operation_info in six.iteritems(operation_data):
                self._maps.operation_info[(service_name, operation_name)] = operation_info
                self._maps.operation_mapping.setdefault(id_,
                                                        []).append((service_name,
                                                                    operation_name))
                service_info.operations[operation_name] = operation_info

            self._maps.service_info[service_name] = service_info
            self._maps.service_mapping.setdefault(id_, []).append(service_name)
            service_map[service_name] = service_info
            package_info.services[service_name] = service_info
            package_map[package_name] = package_info

        # Create ComponentInfo object
        component_info = ComponentInfo(packages={})
        for package_name, package_info in six.iteritems(package_map):
            self._maps.package_info[package_name] = package_info
            self._maps.package_mapping.setdefault(id_, []).append(package_name)
            component_info.packages[package_name] = package_info
        return component_info

    @staticmethod
    def _add_id_types_package(package_map, id_types_map):
        """
        Add com.vmware.routing.idTypes to the list of packages
        of the current product model. This package has
        RoutingInfo containing the id_types map if present.
        :param package_map: The map of packages defined in
        the product model.
        :param id_types_map: The map of id types if present
        """
        if not id_types_map:
            return package_map
        routing_info = RoutingInfo(routing_strategy='', routing_path='', operation_hints=[], id_types=id_types_map)
        package_info_id_types = PackageInfo(routing_info=routing_info, services={})
        package_info_id_types_existing = package_map.get(ID_TYPES_PACKAGE)
        if package_info_id_types_existing:
            package_info_id_types_existing.routing_info.id_types = id_types_map
        else:
            package_map[ID_TYPES_PACKAGE] = package_info_id_types
        return package_map

    def _parse_json_metadata(self, source_id, idl_metadata):
        """
        Parse metadata obtained from a file

        :type  source_id: :class:`str`
        :param source_id: Source metamodel
        :type  idl_metadata: :class:`list` of :class:`dict`
        :param idl_metadata: metamodel metadata
        """
        if not idl_metadata:
            return

        component_data = idl_metadata.get('component')
        if not component_data:
            # Backward compatibility
            component_data = idl_metadata.get('product')
        component_name = component_data.get('name')

        component_info = self._parse_json_component_info(source_id, component_data)
        self._maps.component_info[component_name] = component_info

        self._maps.component_mapping.setdefault(source_id,
                                                []).append(component_name)

        fingerprint = self._generate_fingerprint(component_info)
        self._maps.component_fingerprints[component_name] = fingerprint

    def _parse_remote_service_info(self, source_id, service_name, service_info):
        """
        Parse ServiceInfo remote data

        :type  source_id: :class:`str`
        :param source_id: Source identifier
        :type  service_name: :class:`str`
        :param service_name: Service Name
        :type  service_info: :class:`com.vmware.vapi.metadata.routing_provider.ServiceInfo`
        :param service_info: ServiceInfo object
        """
        for name, info in six.iteritems(service_info.operations):
            self._maps.operation_info[(service_name, name)] = info
            self._maps.operation_mapping.setdefault(source_id, []).append(
                (service_name, name))

    def _parse_remote_package_info(self, source_id, package_info):
        """
        Parse PackageInfo remote data

        :type  source_id: :class:`str`
        :param source_id: Source identifier
        :type  package_info: :class:`com.vmware.vapi.metadata.routing_provider.PackageInfo`
        :param package_info: PackageInfo object
        """
        for name, info in six.iteritems(package_info.services):
            self._parse_remote_service_info(source_id, name, info)
            self._maps.service_info[name] = info
            self._maps.service_mapping.setdefault(source_id, []).append(name)

    def _parse_remote_component_info(self, source_id, component_info):
        """
        Parse ComponentInfo remote data

        :type  source_id: :class:`str`
        :param source_id: Source identifier
        :type  component_info: :class:`com.vmware.vapi.metadata.routing_provider.ComponentInfo`
        :param component_info: ComponentInfo object
        """
        for name, info in six.iteritems(component_info.packages):
            self._parse_remote_package_info(source_id, info)
            self._maps.package_info[name] = info
            self._maps.package_mapping.setdefault(source_id, []).append(name)

    def _parse_remote_metadata(self, source_id, stub_factory):
        """
        Parse metadata obtained from a remote source

        :type  source_id: :class:`str`
        :param source_id: Source identifier
        :type  stub_factory: :class:`vmware.vapi.bindings.stub.StubFactory`
        :param stub_factory: Stub factory
        """
        if not stub_factory:
            return
        component_stub = stub_factory.create_stub(
            'com.vmware.vapi.metadata.routing.component')
        for component_id in component_stub.list():
            component_data = component_stub.get(name=component_id)
            self._parse_remote_component_info(source_id, component_data.info)
            self._maps.component_info[component_id] = component_data.info

            self._maps.component_mapping.setdefault(source_id,
                                                    []).append(component_id)
            self._maps.component_fingerprints[component_id] = component_data.fingerprint


def register_instance(cfg):
    """
    Specify the instances that should be
    registered with the api provider

    :type  cfg: :class:`dict` of :class:`str` and :class:`str`
    :param cfg: Configuration for the service specified in the properties file
    """
    maps = get_routing_maps()
    return [
        OperationImpl(maps),
        PackageImpl(maps),
        ComponentImpl(maps),
        ServiceImpl(maps),
        SourceImpl(maps, cfg),
    ]
