"""
Source Mixin class to manage the metadata sources
"""

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2015-2017 VMware, Inc.  All rights reserved. -- VMware Confidential'  # pylint: disable=line-too-long
__docformat__ = 'restructuredtext en'

import errno
import os
try:
    import simplejson as json
except ImportError:
    import json

from com.vmware.vapi.metadata_provider import SourceType
from com.vmware.vapi.std.errors_provider import NotFound
from vmware.vapi.bindings.stub import StubFactory
from vmware.vapi.bindings.error import VapiError
from vmware.vapi.lib import connect
from vmware.vapi.lib.load import dynamic_import
from vmware.vapi.lib.log import get_vapi_logger
from vmware.vapi.lib.fingerprint import generate_fingerprint
from vmware.vapi.stdlib.client.factories import StubConfigurationFactory
from vmware.vapi.stdlib.provider.factories import MessageFactory, ErrorFactory

messages = {
    'metadata.not_implemented':
        'Method %s is not implemented',
    'metadata.sources.not_found':
        'Source with id %s was not found',
    'metadata.sources.already_exists':
        'Source with id %s already exists',
    'metadata.sources.invalid_argument.source_type':
        'Argument %s is not a valid source type',
    'metadata.sources.invalid_argument':
        'Argument %s is not valid because of %s',
    'metadata.sources.invalid_argument.file_not_found':
        'File %s is not found',
    'metadata.sources.invalid_argument.no_permission':
        'Insufficient permissions to access file %s',
    'metadata.sources.invalid_argument.io_error':
        'IO Error while accessing the file %s',
    'metadata.sources.invalid_remote_argument.vapi_error':
        'Error %s while retrieving data from remote source %s',
    'metadata.sources.invalid_remote_argument.unknown_error':
        'Error %s while retrieving data from remote source %s',
}
message_factory = MessageFactory(messages)
logger = get_vapi_logger(__name__)

METADATA = 'com.vmware.vapi.metadata'


class SourceMixin(object):
    """
    Operations to manage the metadata sources
    """
    def __init__(self, maps, metadata_name, cfg):
        """
        Initialize SourceMixin

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Instance of MetadataMaps that contains all the data for the
            given source
        :type  metadata_name: :class:`str`
        :param metadata_name: Name of the subpackage of the metadata service this
            Source class belongs to. i.e. in case of com.vmware.vapi.metadata.metamodel
            the value here would be 'metamodel'
        :type  cfg: :class:`dict` of :class:`str` and :class:`str`
        :param cfg: Configuration for the service specified in the properties file
        """
        self._maps = maps
        self._metadata_name = metadata_name
        self._maps.update_fingerprint()
        self._certificate = cfg.get('certificate')
        self._private_key = cfg.get('private_key')
        self._ca_certs = cfg.get('ca_certs')
        self._ca_certs_dir = cfg.get('ca_certs_dir')
        self._add_source_from_config(cfg)

    def _add_source_from_config(self, cfg):
        """
        Add the file sources specified in the config file

        :type  cfg: :class:`dict` of :class:`str` and :class:`str`
        :param cfg: Configuration for the service specified in the properties file
        """
        src_ids = cfg.get('sources', '')
        if src_ids:
            for id_ in src_ids.split(','):
                stripped_id = id_.strip('\n\\ \t')
                path_key = 'sources.%s.filepath' % stripped_id
                src_path = os.path.expandvars(cfg.get(path_key, '').strip())
                self.create(source_id=stripped_id,
                            spec=self.CreateSpec(description=stripped_id,
                                                 type=SourceType.FILE,
                                                 filepath=src_path))

    def _get_stub_factory(self, remote_addr, msg_protocol):
        """
        Get the stub factory

        :type  remote_addr: :class:`str`
        :param remote_addr: Remote address
        """
        rpc_protocol = remote_addr.split(':')[0]
        try:
            # If requests is present, use it. Otherwise
            # fall back to basic http connector
            import requests
            session = requests.Session()
            certdir = os.environ.get('CERTDIR')
            if certdir is None:
                certdir = self._ca_certs_dir
            if self._certificate or self._private_key:
                session.verify = True
                if self._ca_certs:
                    session.verify = os.path.join(
                        certdir, self._ca_certs)
                session.cert = (
                    os.path.join(certdir, self._certificate),
                    os.path.join(certdir, self._private_key))
            connector = connect.get_requests_connector(
                session, url=remote_addr)
        except ImportError:
            from vmware.vapi.lib.ssl import DefaultClientContextFactory
            ssl_context = None
            if (self._certificate or self._private_key or self._ca_certs or
                    self._ca_certs_dir):
                ssl_context = DefaultClientContextFactory(
                    certificate=self._certificate,
                    private_key=self._private_key,
                    ca_certs=self._ca_certs,
                    ca_certs_dir=self._ca_certs_dir)
            connector = connect.get_connector(rpc_protocol,
                                              msg_protocol,
                                              url=remote_addr,
                                              ssl_context=ssl_context)
        stub_config = StubConfigurationFactory.new_std_configuration(connector)
        return StubFactory(stub_config)

    @staticmethod
    def _generate_fingerprint(input_obj):
        """
        Generate a fingerprint for the input object

        :type  input_obj: :class:`object`
        :param input_obj: Input object
        :rtype: :class:`str`
        :return: MD5 fingerprint for the object
        """
        data = input_obj.__repr__()
        return generate_fingerprint(data)

    @staticmethod
    def _generate_fingerprint_from_file(filename):
        """
        Return the last modified time for the specified file

        :type  filename: :class:`str`
        :param filename: File path
        :rtype: :class:`str`
        :return: The last modified time for the file
        """
        return str(os.path.getmtime(filename))

    def _parse_json_metadata(self, id_, json_metadata_list):
        """
        Parse json metadata

        :type  id_: :class:`str`
        :param id_: Source identifier
        :type  json_metadata_list: :class:`list` of :class:`dict`
        :param json_metadata_list: Metadata list
        """
        raise NotImplementedError

    def _parse_remote_metadata(self, id_, remote_metadata):
        """
        Parse metadata obtained from a remote source

        :type  id_: :class:`str`
        :param id_: Source identifier
        :type  remote_metadata: :class:`list` of :class:`OperationInfo`
        :param remote_metadata: Metadata
        """
        raise NotImplementedError

    def _source_cleanup(self, source_id):
        """
        Cleanup the source

        :type  source_id: :class:`str`
        :param source_id: Source identifier
        """
        try:
            self.delete(source_id=source_id)
        except NotFound:
            pass

    def _add_file(self, id_, file_name):
        """
        Add a metadata file source

        :type  id_: :class:`str`
        :param id_: Source identifier
        :type  file_name: :class:`str`
        :kwarg file_name: Absolute path of the metadata file
        """
        try:
            with open(file_name) as json_fp:
                metadata = json.load(json_fp)
                # pylint thinks that metadata is a bool, even though json.load
                # returns a python object
                json_metadata = metadata.get(self._metadata_name)  # pylint: disable=E1103
                self._maps.source_fingerprints[id_] = self._generate_fingerprint_from_file(file_name)
                self._parse_json_metadata(id_, json_metadata)
        except IOError as err:
            if err.errno == errno.ENOENT:
                msg = message_factory.get_message(
                    'metadata.sources.invalid_argument.file_not_found',
                    file_name)
                error = ErrorFactory.new_not_found(messages=[msg])
            elif err.errno == errno.EACCES:
                msg = message_factory.get_message(
                    'metadata.sources.invalid_argument.no_permission',
                    file_name)
                error = ErrorFactory.new_invalid_argument(messages=[msg])
            else:
                msg = message_factory.get_message(
                    'metadata.sources.invalid_argument.io_error',
                    file_name)
                error = ErrorFactory.new_invalid_argument(messages=[msg])
            logger.exception(msg)
            self._source_cleanup(id_)
            raise error
        except Exception as err:
            msg = message_factory.get_message(
                'metadata.sources.invalid_argument', file_name, str(err))
            logger.exception(msg)
            self._source_cleanup(id_)
            raise ErrorFactory.new_invalid_argument(messages=[msg])

    def _add_remote(self, id_, remote_addr, msg_protocol):
        """
        Add a remote metadata source

        :type  id: :class:`str`
        :kwarg id: Metadata source id
        :type  remote_addr: :class:`str`
        :kwarg remote_addr: Address of the remote vAPI metadata server
        :type  msg_protocol: :class:`str`
        :kwarg msg_protocol: Message protocol to be used
        """
        try:
            stub_factory = self._get_stub_factory(remote_addr,
                                                  msg_protocol)
            metadata_client = stub_factory.create_stub(
                '%s.%s.%s' % (METADATA, self._metadata_name, 'source'))
            self._maps.source_fingerprints[id_] = metadata_client.fingerprint()
            self._parse_remote_metadata(id_, stub_factory)
        except VapiError as err:
            msgs = [message_factory.get_message(
                'metadata.sources.invalid_remote_argument.vapi_error',
                repr(err), remote_addr)]
            if hasattr(err, 'messages'):
                msgs.extend(err.messages)  # pylint: disable=E1101
            logger.exception(msgs)
            self._source_cleanup(id_)
            raise ErrorFactory.new_invalid_argument(messages=msgs)
        except Exception as err:
            msg = message_factory.get_message(
                'metadata.sources.invalid_remote_argument.unknown_error',
                repr(err), remote_addr)
            logger.exception(msg)
            self._source_cleanup(id_)
            raise ErrorFactory.new_invalid_argument(messages=[msg])

    def create(self, source_id, spec):
        """
        Create a new metadata source.

        :type  source_id: :class:`str`
        :param source_id: metadata source identifier.
        :type  spec: :class:`com.vmware.vapi.metadata.metamodel_provider.Source.CreateSpec`
        :param spec: create specification.
        :raise: :class:`com.vmware.vapi.std.errors_provider.AlreadyExists` If the metadata
            source identifier is already present.
        :raise: :class:`com.vmware.vapi.std.errors_provider.InvalidArgument` [If type of the source is invalid.]
            [If the remote vAPI provider address is invalid.]
            If the message protocol specified is invalid.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound` If the file specified does not exist.
        """
        if source_id in self._maps.sources:
            msg = message_factory.get_message(
                'metadata.sources.already_exists', source_id)
            logger.error(msg)
            raise ErrorFactory.new_already_exists(messages=[msg])

        if spec.type not in [SourceType.FILE, SourceType.REMOTE]:
            msg = message_factory.get_message(
                'metadata.sources.invalid_argument.source_type', spec.type)
            logger.error(msg)
            raise ErrorFactory.new_invalid_argument(messages=[msg])

        # Store the source information
        cls = dynamic_import(
            '%s.%s_provider' % (METADATA, self._metadata_name))
        self._maps.sources[source_id] = cls.Source.Info(
            type=spec.type,
            filepath=spec.filepath,
            address=spec.address,
            description=spec.description)

        if spec.type == SourceType.FILE:
            self._add_file(source_id, spec.filepath)
        elif spec.type == SourceType.REMOTE:
            self._add_remote(source_id, spec.address, 'json')

        self._maps.update_fingerprint()

    def delete(self, source_id):
        """
        Delete a metadata source.

        :type  source_id: :class:`str`
        :param source_id: Metadata source identifier.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound` If the metadata source identifier is not found.
        """
        if source_id not in self._maps.sources:
            msg = message_factory.get_message('metadata.sources.not_found',
                                              source_id)
            logger.error(msg)
            raise ErrorFactory.new_not_found(messages=[msg])

        self._maps.remove(source_id)
        self._maps.update_fingerprint()

    def get(self, source_id):
        """
        Get the details about a metadata source.

        :type  source_id: :class:`str`
        :param source_id: Metadata source identifier.
        :rtype: :class:`com.vmware.vapi.metadata.metamodel_provider.Source.Info`
        :return: Metadata source info.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound` If the metadata source identifier is not found.
        """
        if source_id not in self._maps.sources:
            msg = message_factory.get_message('metadata.sources.not_found', source_id)
            logger.error(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return self._maps.sources.get(source_id)

    def reload(self, source_id=None):
        """
        Reload metadata from all the sources or of a particular source.

        :type  source_id: :class:`str` or ``None``
        :param source_id: Metadata source identifier.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound` If the metadata source identifier is not found.
        """
        ids_to_reload = []

        if source_id:
            if source_id in self._maps.sources:
                ids_to_reload = [source_id]
            else:
                msg = message_factory.get_message('metadata.sources.not_found',
                                                  source_id)
                logger.error(msg)
                raise ErrorFactory.new_not_found(messages=[msg])
        else:
            ids_to_reload = self._maps.sources.keys()

        # For all the remote sources, get the new fingerprint
        # and reload only if the fingerprint changes
        # For all the file sources, reload
        for src_id in ids_to_reload:
            source_info = self._maps.sources[src_id]

            re_register = False
            if source_info.type == SourceType.FILE:
                fingerprint = self._generate_fingerprint_from_file(source_info.filepath)
            else:
                stub_factory = self._get_stub_factory(source_info.address, 'json')
                metadata_client = stub_factory.create_stub(
                    '%s.%s.%s' % (METADATA, self._metadata_name, 'source'))
                fingerprint = metadata_client.fingerprint()
            if fingerprint != self._maps.source_fingerprints.get(src_id):
                re_register = True

            if re_register:
                self.delete(source_id=src_id)
                cls = dynamic_import(
                    '%s.%s_provider' % (METADATA, self._metadata_name))
                spec = cls.Source.CreateSpec(type=source_info.type,
                                             filepath=source_info.filepath,
                                             address=source_info.address,
                                             description=source_info.description)
                self.create(source_id=src_id, spec=spec)

    def fingerprint(self, source_id=None):
        """
        Returns the checksum of all the sources or for a particular source.

        :type  source_id: :class:`str` or ``None``
        :param source_id: Metadata source identifier.
        :rtype: :class:`str`
        :return:
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound` If the metadata source identifier is not found.
        """
        if not source_id:
            return self._maps.fingerprint

        try:
            return self._maps.source_fingerprints[source_id]
        except KeyError:
            msg = message_factory.get_message('metadata.sources.not_found',
                                              source_id)
            logger.error(msg)
            raise ErrorFactory.new_not_found(messages=[msg])

    def list(self):
        """
        List all the metadata sources

        :rtype: :class:`list` of :class:`str`
        :return: List of all metadata source
        """
        return self._maps.sources.keys()
