"""
Metamodel services for vAPI
"""

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2015-2017 VMware, Inc.  All rights reserved. -- VMware Confidential'  # pylint: disable=line-too-long
__docformat__ = 'restructuredtext en'

import six

from com.vmware.vapi.metadata.metamodel_provider import (
    Component, ComponentData, Package, Service, Structure,
    Source, ComponentInfo, PackageInfo, ServiceInfo, StructureInfo,
    OperationInfo, Type, FieldInfo, EnumerationInfo,
    OperationResultInfo, ErrorInfo, GenericInstantiation,
    ElementMap, ElementValue, ConstantInfo, ConstantValue, PrimitiveValue,
    Enumeration, EnumerationValueInfo, UserDefinedType, Resource)
from com.vmware.vapi.metadata.metamodel.service_provider import Operation
from com.vmware.vapi.metadata.metamodel.resource_provider import Model
from com.vmware.vapi.metadata.util.maps import get_metamodel_maps
from com.vmware.vapi.metadata.util.sources_mixin import SourceMixin
from vmware.vapi.lib.log import get_vapi_logger
from vmware.vapi.stdlib.provider.factories import MessageFactory, ErrorFactory

messages = {
    'metadata.metamodel.component.not_found':
        'Component %s does not have any metamodel information',
    'metadata.metamodel.package.not_found':
        'Package %s does not have any metamodel information',
    'metadata.metamodel.service.not_found':
        'Service %s does not have any metamodel information',
    'metadata.metamodel.structure.not_found':
        'Structure %s does not have any metamodel information',
    'metadata.metamodel.enumeration.not_found':
        'Enumeration %s does not have any metamodel information',
    'metadata.metamodel.operation.not_found':
        'Operation %s in Service %s does not have any metamodel information',
    'metadata.metamodel.sources.invalid_type_category':
        'Type category %s is invalid',
    'metadata.metamodel.sources.invalid_builtin_type':
        'Primitive type %s is invalid',
    'metadata.metamodel.sources.invalid_generic_type':
        'Generic type %s is invalid',
    'metadata.metamodel.sources.invalid_user_defined_type':
        'User defined type %s is invalid',
    'metadata.metamodel.sources.invalid_structure_type':
        'Structure type %s is invalid',
    'metadata.metamodel.sources.invalid_constant_type_category':
        'Type category %s of constant is invalid',
    'metadata.metamodel.sources.invalid_constant_builtin_type':
        'Primitive type %s for constant is invalid',
    'metadata.sources.already_exists':
        'Source with id %s already exists',
    'metadata.sources.invalid_argument.source_type':
        'Argument %s is not a valid source type',
    'metadata.metamodel.resource.not_found':
        'Resource type %s is not found',
}
message_factory = MessageFactory(messages)
logger = get_vapi_logger(__name__)
METAMODEL = 'metamodel'


class ResourceImpl(Resource):
    """
    The :class:`Resource` service provides operations to retrieve information
    about resource types present across all the services registered with the
    metamodel metadata service.
    """
    def __init__(self, maps):
        """
        Initialize ResourceImpl

        :type  maps:
            :class:`com.vmware.vapi.metadata.identifier.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Resource.__init__(self)
        self._maps = maps

    def list(self):
        """
        Returns the set of resource types present across all the services
        registered with the metamodel metadata service.

        :rtype: :class:`set` of :class:`str`
        :return: Set of resource types
        """
        result = set()
        for resource_types in self._maps.resource_mapping.values():
            result.update(resource_types)
        return result


class ModelImpl(Model):
    """
    The :class:`Model` service provides operations to retrieve information about
    resource model types.
    """
    def __init__(self, maps):
        """
        Initialize ModelImpl

        :type  maps:
            :class:`com.vmware.vapi.metadata.identifier.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Model.__init__(self)
        self._maps = maps

    def list(self, resource_id):
        """
        Returns the set of structure identifiers for all the structure types
        that are models for the give resource type. The
        :class:`com.vmware.vapi.metadata.metamodel_provider.Structure`
        service provides operations to retrieve more details about the
        structures corresponding to the structure identifiers returned by this
        operation.

        :type  resource_id: :class:`str`
        :param resource_id: Resource type identifier.
        :rtype: :class:`set` of :class:`str`
        :return: Set of structure identifiers that are models for the given
            resource type.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound` if the
            resource type does not exist.
        """
        models = self._maps.model_info.get(resource_id)
        if models is None:
            msg = message_factory.get_message(
                'metadata.metamodel.resource.not_found',
                resource_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return models


class EnumerationImpl(Enumeration):
    """
    Operations to retrieve metamodel information about a vAPI enumerated type.
    """
    def __init__(self, maps):
        """
        Initialize EnumerationImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Enumeration.__init__(self)
        self._maps = maps

    def list(self):
        """
        Get list of all vAPI enumerated types.

        :rtype: :class:`list` of :class:`str`
        :return: List of enumeration identifiers.
        """
        return self._maps.enumeration_info.keys()

    def get(self, enumeration_id):
        """
        Get the metamodel information of a vAPI enumerated type.

        :type  enumeration_id: :class:`str`
        :param enumeration_id:
        :rtype:
            :class:`com.vmware.vapi.metadata.metamodel_provider.EnumerationInfo`
        :return: Metamodel information of the enumerated type.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound` if the
            enumerated identifier does not exists.
        """
        enumeration_info = self._maps.enumeration_info.get(enumeration_id)
        if enumeration_info is None:
            msg = message_factory.get_message(
                'metadata.metamodel.enumeration.not_found',
                enumeration_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return enumeration_info


class OperationImpl(Operation):
    """
    Operations to retrieve metamodel information of a vAPI operation.
    """
    def __init__(self, maps):
        """
        Initialize OperationImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Operation.__init__(self)
        self._maps = maps

    def list(self, service_id):
        """
        Get the IDs of all the vAPI operations in the given service.

        :type  service_id: :class:`str`
        :param service_id: Service identifier.
        :rtype: :class:`list` of :class:`str`
        :return: List of operation identifiers.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound` if the
            service identifier does not exist.
        """
        if service_id not in self._maps.service_info:
            msg = message_factory.get_message(
                'metadata.metamodel.service.not_found',
                service_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return [operation_id
                for svc_id, operation_id in self._maps.operation_info.keys()
                if svc_id == service_id]

    def get(self, service_id, operation_id):
        """
        Get the metamodel information of a vAPI operation.

        :type  service_id: :class:`str`
        :param service_id: Service identifier.
        :type  operation_id: :class:`str`
        :param operation_id: Operation identifier.
        :rtype:
            :class:`com.vmware.vapi.metadata.metamodel_provider.OperationInfo`
        :return: Metamodel information of the vAPI operation.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound` if the
            service identifier does not exist.
        """
        operation_info = self._maps.operation_info.get((service_id,
                                                        operation_id))
        if operation_info is None:
            msg = message_factory.get_message(
                'metadata.metamodel.operation.not_found',
                operation_id, service_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return operation_info


class PackageImpl(Package):
    """
    Operations to retrieve metamodel information about a vAPI package.
    """
    def __init__(self, maps):
        """
        Initialize PackageImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Package.__init__(self)
        self._maps = maps

    def list(self):
        """
        Get list of all vAPI packages.

        :rtype: :class:`list` of :class:`str`
        :return: List of package identifiers.
        """
        return self._maps.package_info.keys()

    def get(self, package_id):
        """
        Get the metamodel info of a vAPI package.

        :type  package_id: :class:`str`
        :param package_id: Package identifier.
        :rtype: :class:`com.vmware.vapi.metadata.metamodel_provider.PackageInfo`
        :return: Metamodel information of the vAPI package.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound` if the
            package identifier does not exist.
        """
        package_info = self._maps.package_info.get(package_id)
        if package_info is None:
            msg = message_factory.get_message(
                'metadata.metamodel.package.not_found',
                package_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return package_info


class ComponentImpl(Component):
    """
    Operations to retrieve metamodel information about a vAPI component.
    """
    def __init__(self, maps):
        """
        Initialize ComponentImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Component.__init__(self)
        self._maps = maps

    def list(self):
        """
        Get list of all vAPI components.

        :rtype: :class:`list` of :class:`str`
        :return: List of component identifiers.
        """
        return self._maps.component_info.keys()

    def get(self, component_id):
        """
        Get the metamodel information of a vAPI component.

        :type  component_id: :class:`str`
        :param component_id: Component identifier.
        :rtype:
            :class:`com.vmware.vapi.metadata.metamodel_provider.ComponentData`
        :return: Metamodel information of the vAPI component.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound` if the
            component identifier does not exist.
        """
        component_info = self._maps.component_info.get(component_id)
        if component_info is None:
            msg = message_factory.get_message(
                'metadata.metamodel.component.not_found',
                component_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return ComponentData(
            info=component_info,
            fingerprint=self.fingerprint(component_id=component_id))

    def fingerprint(self, component_id):
        """
        fingerprint of all metadata of a vAPI component on the server.

        :type  component_id: :class:`str`
        :param component_id: Component identifier.
        :rtype: :class:`str`
        :return: fingerprint of metadata of a vAPI component.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound` if the
            component identifier does not exist.
        """
        fingerprint = self._maps.component_fingerprints.get(component_id)
        if fingerprint is None:
            msg = message_factory.get_message(
                'metadata.metamodel.component.not_found',
                component_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return fingerprint


class ServiceImpl(Service):
    """
    Operations to retrieve metamodel information about a vAPI service.
    """
    def __init__(self, maps):
        """
        Initialize ServiceImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Service.__init__(self)
        self._maps = maps

    def list(self):
        """
        Get list of all vAPI services.

        :rtype: :class:`list` of :class:`str`
        :return: List of service identifiers.
        """
        return self._maps.service_info.keys()

    def get(self, service_id):
        """
        Get the metamodel information of a vAPI service.

        :type  service_id: :class:`str`
        :param service_id: Service identifier.
        :rtype: :class:`com.vmware.vapi.metadata.metamodel_provider.ServiceInfo`
        :return: Metamodel information of the vAPI service.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound` if the
            service identifier does not exist.
        """
        service_info = self._maps.service_info.get(service_id)
        if service_info is None:
            msg = message_factory.get_message(
                'metadata.metamodel.service.not_found',
                service_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return service_info


class StructureImpl(Structure):
    """
    Operations to retrieve metamodel information about a vAPI structure.
    """
    def __init__(self, maps):
        """
        Initialize StructureImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Structure.__init__(self)
        self._maps = maps

    def list(self):
        """
        Get list of all vAPI structures.

        :rtype: :class:`list` of :class:`str`
        :return: List of structure identifiers.
        """
        return self._maps.structure_info.keys()

    def get(self, structure_id):
        """
        Get the metamodel information of a vAPI structure.

        :type  structure_id: :class:`str`
        :param structure_id: Structure identifier.
        :rtype:
            :class:`com.vmware.vapi.metadata.metamodel_provider.StructureInfo`
        :return: Metamodel information of the structure.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound` if the
            structure identifier does not exist.
        """
        structure_info = self._maps.structure_info.get(structure_id)
        if structure_info is None:
            msg = message_factory.get_message(
                'metadata.metamodel.structure.not_found',
                structure_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return structure_info


class SourceImpl(SourceMixin, Source):
    """
    Operations to manage the metadata sources for metamodel information.
    """
    _categories_map = {
        'primitive': Type.Category.BUILTIN,
        'user_defined': Type.Category.USER_DEFINED,
        'generic': Type.Category.GENERIC,
    }
    _builtin_types_map = {
        'boolean': Type.BuiltinType.BOOLEAN,
        'long': Type.BuiltinType.LONG,
        'double': Type.BuiltinType.DOUBLE,
        'string': Type.BuiltinType.STRING,
        'void': Type.BuiltinType.VOID,
        'opaque': Type.BuiltinType.OPAQUE,
        'binary': Type.BuiltinType.BINARY,
        'date_time': Type.BuiltinType.DATE_TIME,
        'secret': Type.BuiltinType.SECRET,
        'URI': Type.BuiltinType.URI,
        'ID': Type.BuiltinType.ID,
        'structure': Type.BuiltinType.DYNAMIC_STRUCTURE,
        'dynamic_structure': Type.BuiltinType.DYNAMIC_STRUCTURE,
        'exception': Type.BuiltinType.ANY_ERROR,
    }
    _generic_types_map = {
        'List': GenericInstantiation.GenericType.LIST,
        'Optional': GenericInstantiation.GenericType.OPTIONAL,
        'Set': GenericInstantiation.GenericType.SET,
        'Map': GenericInstantiation.GenericType.MAP,
    }
    _user_defined_types_map = {
        'Structure': Structure.RESOURCE_TYPE,
        'Enumeration': Enumeration.RESOURCE_TYPE,
    }
    _structure_types_map = {
        'Structure': StructureInfo.Type.STRUCTURE,
        'Error': StructureInfo.Type.ERROR
    }
    _constant_categories_map = {
        'Primitive': ConstantValue.Category.PRIMITIVE,
        'List': ConstantValue.Category.LIST
    }
    _constant_types_map = {
        'Boolean': PrimitiveValue.Type.BOOLEAN,
        'Double': PrimitiveValue.Type.DOUBLE,
        'Long': PrimitiveValue.Type.LONG,
        'String': PrimitiveValue.Type.STRING
    }

    def __init__(self, maps, cfg):
        """
        Initialize SourcesImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        :type  cfg: :class:`dict` of :class:`str` and :class:`str`
        :param cfg: Configuration for the service specified in the properties
            file
        """
        Source.__init__(self)
        SourceMixin.__init__(self, maps, METAMODEL, cfg)

    @classmethod
    def _parse_generic_instantiation(cls, type_string):
        """
        Parse json generic type object

        :type  type_string: :class:`str`
        :param type_string: Json type string object
        :rtype: :class:`com.vmware.vapi.metadata.metamodel_provider
            .GenericInstantiation`
        :return: GenericInstantiation object
        """
        generic_type = type_string.get('generic_type')
        if generic_type == 'Map':
            map_key_type = type_string.get('map_key_type')
            map_value_type = type_string.get('map_value_type')
            type_info = GenericInstantiation(
                generic_type=cls._generic_types_map[generic_type],
                map_key_type=cls._parse_type(map_key_type),
                map_value_type=cls._parse_type(map_value_type))
        else:
            element_type = type_string.get('element_type')
            type_info = GenericInstantiation(
                generic_type=cls._generic_types_map[generic_type],
                element_type=cls._parse_type(element_type))
        return type_info

    @classmethod
    def _parse_type(cls, type_string):
        """
        Parse json type object

        :type  type_string: :class:`str`
        :param type_string: Json type string object
        :rtype: :class:`com.vmware.vapi.metadata.metamodel_provider.Type`
        :return: Type object
        """
        category = type_string.get('category')
        if category == 'generic':
            generic_type = type_string.get('generic_type')
            if generic_type not in cls._generic_types_map:
                msg = message_factory.get_message(
                    'metadata.metamodel.sources.invalid_generic_type',
                     generic_type)
                raise ErrorFactory.new_invalid_argument(messages=[msg])
            type_info = Type(
                category=cls._categories_map[category],
                generic_instantiation=cls._parse_generic_instantiation(
                    type_string))
        elif category == 'user_defined':
            user_defined_type = type_string.get('user_defined_type')
            if user_defined_type not in cls._user_defined_types_map:
                msg = message_factory.get_message(
                    'metadata.metamodel.sources.invalid_user_defined_type',
                     user_defined_type)
                raise ErrorFactory.new_invalid_argument(messages=[msg])
            type_info = Type(
                category=cls._categories_map[category],
                user_defined_type=UserDefinedType(
                    resource_type=cls._user_defined_types_map[
                        user_defined_type],
                    resource_id=type_string.get('user_defined_type_name')))
        elif category == 'primitive':
            builtin_type = type_string.get('primitive_type')
            if builtin_type not in cls._builtin_types_map:
                msg = message_factory.get_message(
                    'metadata.metamodel.sources.invalid_builtin_type',
                     builtin_type)
                raise ErrorFactory.new_invalid_argument(messages=[msg])
            type_info = Type(
                category=cls._categories_map[category],
                builtin_type=cls._builtin_types_map[builtin_type])
        else:
            msg = message_factory.get_message(
                'metadata.metamodel.sources.invalid_type_category',
                 category)
            raise ErrorFactory.new_invalid_argument(messages=[msg])
        return type_info

    def _parse_json_metadata_info(self, source_id, metadata_json_data):
        """
        Parse metadata json object

        :type  metadata_json_data: :class:`list` of :class:`dict`
        :param metadata_json_data: Metadata json object
        :rtype: :class:`list` of
            :class:`com.vmware.vapi.metadata.metamodel_provider.Metadata`
        :return: Metadata objects
        """
        result = {}
        for name, value in six.iteritems(metadata_json_data):
            element_map = {}
            for k, v in six.iteritems(value):
                if isinstance(v, list):
                    element_value = ElementValue(
                        type=ElementValue.Type.STRING_LIST,
                        list_value=v)
                    if name == 'Resource' and k == 'value':
                        self._maps.resource_mapping.setdefault(
                            source_id, set()).update(v)
                else:
                    element_value = ElementValue(
                        type=ElementValue.Type.STRING,
                        string_value=v)
                    if name == 'Resource' and k == 'value':
                        self._maps.resource_mapping.setdefault(
                            source_id, set()).add(v)
                element_map[k] = element_value
            result[name] = ElementMap(elements=element_map)
        return result

    def _parse_json_field_info(self, source_id, field_data):
        """
        Parse field info json object

        :type  field_data: :class:`dict`
        :param field_data: FieldInfo json object
        :rtype: :class:`com.vmware.vapi.metadata.metamodel_provider.FieldInfo`
        :return: FieldInfo object
        """
        name = field_data.get('name')
        type_info = self._parse_type(field_data.get('type'))
        metadata = self._parse_json_metadata_info(
            source_id, field_data.get('metadata', {}))
        documentation = field_data.get('documentation')
        return FieldInfo(name=name,
                         type=type_info,
                         metadata=metadata,
                         documentation=documentation)

    def _parse_json_enumeration_data(self, source_id, enumeration_json_data):
        """
        Parse a list of json enumeration objects

        :type  source_id: :class:`str`
        :param source_id: Source metamodel
        :type  enumeration_json_data: :class:`list` of :class:`dict`
        :param enumeration_json_data: Json enumeration objects
        :rtype: :class:`dict` of :class:`str` and
            :class:`com.vmware.vapi.metadata.metamodel_provider.EnumerationInfo`
        :return: map of enumerated type name to EnumerationInfo objects
        """
        enumerations = {}
        for enumeration_data in enumeration_json_data:
            # Backward compatibility: values is a dict instead of a lit
            values_data = enumeration_data.get('values')
            values = []
            if isinstance(values_data, list):
                for value_data in enumeration_data.get('values'):
                    value = value_data.get('name')
                    metadata = self._parse_json_metadata_info(
                        source_id, value_data.get('metadata', {}))
                    documentation = value_data.get('documentation')
                    values.append(
                        EnumerationValueInfo(
                            value=value, metadata=metadata,
                            documentation=documentation))
            else:
                for value, documentation in six.iteritems(values_data):
                    values.append(
                        EnumerationValueInfo(
                            value=value, metadata={},
                            documentation=documentation))
            name = enumeration_data.get('name')
            documentation = enumeration_data.get('documentation')
            # Backward compatibility: Get {} for metadata
            metadata = self._parse_json_metadata_info(
                source_id, enumeration_data.get('metadata', {}))
            info = EnumerationInfo(name=name,
                                   documentation=documentation,
                                   values=values,
                                   metadata=metadata)
            self._maps.enumeration_info[name] = info
            self._maps.enumeration_mapping.setdefault(source_id,
                                                      []).append(name)
            enumerations[name] = info
        return enumerations

    @staticmethod
    def _parse_constant_value(constant_type, json_value):
        """
        Parse json constant value

        :type  constant_type: :class:`com.vmware.vapi.metadata
            .metamodel_provider.PrimitiveValue.Type`
        :param constant_type: Type of the value of the constant
        :type  json_value: :class:`dict`
        :param json_value: Json value of the constant
        :rtype: :class:`tuple` of :class:`com.vmware.vapi.metadata
            .metamodel_provider.Type`,
            :class:`com.vmware.vapi.metadata.metamodel_provider.PrimitiveValue`
        :return: Returns the metamodel type and value for the constant
        """
        typ, value = None, None
        if constant_type == PrimitiveValue.Type.BOOLEAN:
            value = PrimitiveValue(type=constant_type,
                                   boolean_value=json_value)
            typ = Type(category=Type.Category.BUILTIN,
                       builtin_type=Type.BuiltinType.BOOLEAN)
        elif constant_type == PrimitiveValue.Type.DOUBLE:
            value = PrimitiveValue(type=constant_type,
                                   double_value=json_value)
            typ = Type(category=Type.Category.BUILTIN,
                       builtin_type=Type.BuiltinType.DOUBLE)
        elif constant_type == PrimitiveValue.Type.LONG:
            value = PrimitiveValue(type=constant_type,
                                   long_value=json_value)
            typ = Type(category=Type.Category.BUILTIN,
                       builtin_type=Type.BuiltinType.LONG)
        else:
            value = PrimitiveValue(type=constant_type,
                                   string_value=json_value)
            typ = Type(category=Type.Category.BUILTIN,
                       builtin_type=Type.BuiltinType.STRING)
        return typ, value

    def _parse_json_constant_data(self, constant_json_data):
        """
        Parse a list of json constant objects

        :type  constant_json_data: :class:`list` of :class:`dict`
        :param constant_json_data: Json constant objects
        :rtype: :class:`dict` of :class:`str` and
            :class:`com.vmware.vapi.metadata.metamodel_provider.ConstantInfo`
        :return: map of constant name to ConstantInfo objects
        """
        constants = {}
        for constant_data in constant_json_data:
            name = constant_data.get('name')
            documentation = constant_data.get('documentation')
            json_value = constant_data.get('value')
            json_type = constant_data.get('type')
            category = json_type.get('category')
            category_val = self._constant_categories_map.get(category)
            if not category_val:
                msg = message_factory.get_message(
                    'metadata.metamodel.sources.invalid_constant_type_category',
                    category)
                logger.info(msg)
                raise ErrorFactory.new_invalid_argument(messages=[msg])
            type_ = json_type.get('type')
            type_value = self._constant_types_map.get(type_)
            if not type_value:
                msg = message_factory.get_message(
                    'metadata.metamodel.sources.'
                    'invalid_constant_primitive_type', type_)
                logger.info(msg)
                raise ErrorFactory.new_invalid_argument(messages=[msg])

            constant_type = None
            if category_val == ConstantValue.Category.PRIMITIVE:
                constant_type, primitive_value = self._parse_constant_value(
                    type_value, json_value)
                constant_value = ConstantValue(category=category_val,
                                               primitive_value=primitive_value)
            else:
                element_type = None
                element_values = []
                for val in json_value:
                    element_type, element_value = self._parse_constant_value(
                        type_value, val)
                    element_values.append(element_value)
                generic_type = GenericInstantiation(
                    generic_type=GenericInstantiation.GenericType.LIST,
                    element_type=element_type)
                constant_type = Type(category=Type.Category.GENERIC,
                                     generic_instantiation=generic_type)
                constant_value = ConstantValue(category=category_val,
                                               list_value=element_values)
            info = ConstantInfo(documentation=documentation,
                                type=constant_type,
                                value=constant_value)
            constants[name] = info
        return constants

    def _process_model_info(self, structure_id, info):
        """
        Process the model info for the given structure. This function is used
        for both local and remote data.

        :type  name: :class:`str`
        :param name: structure identifier
        :type  info:
            :class:`com.vmware.vapi.metadata.metamodel_provider.StructureInfo`
        :param info: Structure information
        """
        if 'Model' not in info.metadata:
            return

        fields = info.fields
        for field in fields:
            if 'ModelKey' in field.metadata and 'Resource' in field.metadata:
                resource_metadata = field.metadata['Resource'].elements
                value = resource_metadata.get('value')
                if value:
                    if value.type == ElementValue.Type.STRING:
                        self._maps.model_info.setdefault(
                            value.string_value, set()).add(structure_id)

    def _parse_json_structure_info(self, source_id, structure_data):
        """
        Parse Structure Info json object

        :type  source_id: :class:`str`
        :param source_id: Source metamodel
        :type  structure_data: :class:`dict`
        :param structure_data: Structure Info json object
        :rtype:
            :class:`com.vmware.vapi.metadata.metamodel_provider.StructureInfo`
        :return: StructureInfo object
        """
        name = structure_data.get('name')
        structure_type = structure_data.get('type')
        structure_type_value = self._structure_types_map.get(structure_type)
        if not structure_type_value:
            msg = message_factory.get_message(
                'metadata.metamodel.sources.invalid_structure_type',
                structure_type)
            logger.info(msg)
            raise ErrorFactory.new_invalid_argument(messages=[msg])
        enumerations = self._parse_json_enumeration_data(
            source_id, structure_data.get('enumerations', []))
        constants = self._parse_json_constant_data(
            structure_data.get('constants', []))
        fields = []
        for field_data in structure_data.get('fields', []):
            info = self._parse_json_field_info(source_id, field_data)
            fields.append(info)
        metadata = self._parse_json_metadata_info(
            source_id, structure_data.get('metadata', {}))
        documentation = structure_data.get('documentation')
        info = StructureInfo(name=name,
                             type=structure_type_value,
                             enumerations=enumerations,
                             constants=constants,
                             fields=fields,
                             metadata=metadata,
                             documentation=documentation)
        self._process_model_info(name, info)
        return info

    def _parse_json_operation_info(self, source_id, operation_data):
        """
        Parse operation Info json object

        :type  operation_data: :class:`dict`
        :param operation_data: Structure Info json object
        :rtype:
            :class:`com.vmware.vapi.metadata.metamodel_provider.OperationInfo`
        :return: OperationInfo object
        """
        name = operation_data.get('name')
        params = []
        for param_data in operation_data.get('params', []):
            param_info = self._parse_json_field_info(source_id, param_data)
            params.append(param_info)
        result_data = operation_data.get('result')
        result_metadata = self._parse_json_metadata_info(
            source_id, result_data.get('metadata', {}))
        output = OperationResultInfo(
            type=self._parse_type(result_data.get('type')),
            metadata=result_metadata,
            documentation=result_data.get('documentation'))
        errors_data = operation_data.get('errors', [])
        errors = [
            ErrorInfo(
                structure_id=error_data.get('user_defined_type_name'),
                documentation=error_data.get('documentation'))
            for error_data in errors_data]
        metadata = self._parse_json_metadata_info(
            source_id, operation_data.get('metadata', {}))
        documentation = operation_data.get('documentation')
        return OperationInfo(name=name,
                             params=params,
                             output=output,
                             errors=errors,
                             metadata=metadata,
                             documentation=documentation)

    def _parse_json_structure_data(self, source_id, structure_json_data):
        """
        Parse a list of json structure objects

        :type  source_id: :class:`str`
        :param source_id: Source metamodel
        :type  structure_json_data: :class:`list` of :class:`dict`
        :param structure_json_data: Json structure objects
        :rtype: :class:`dict` of :class:`str` and
            :class:`com.vmware.vapi.metadata.metamodel_provider.StructureData`
        :return: Map of structure names to StructureInfo objects
        """
        structures = {}
        for structure_data in structure_json_data:
            name = structure_data.get('name')
            info = self._parse_json_structure_info(source_id, structure_data)
            self._maps.structure_info[name] = info
            self._maps.structure_mapping.setdefault(source_id,
                                                    []).append(name)
            structures[name] = info
        return structures

    def _parse_json_service_info(self, source_id, service_data):
        """
        Parse Service Info json object

        :type  source_id: :class:`str`
        :param source_id: Source metamodel
        :type  service_data: :class:`dict`
        :param service_data: Structure Info json object
        :rtype: :class:`com.vmware.vapi.metadata.metamodel_provider.ServiceInfo`
        :return: ServiceInfo object
        """
        service_name = service_data.get('name')
        operations = {}
        for operation_data in service_data.get('operations', []):
            name = operation_data.get('name')
            info = self._parse_json_operation_info(source_id, operation_data)
            operations[name] = info
            self._maps.operation_info[(service_name, name)] = info
            self._maps.operation_mapping.setdefault(source_id,
                                                    []).append((service_name,
                                                                name))
        structures = self._parse_json_structure_data(
            source_id, service_data.get('structures', []))
        enumerations = self._parse_json_enumeration_data(
            source_id, service_data.get('enumerations', []))
        constants = self._parse_json_constant_data(
            service_data.get('constants', []))
        metadata = self._parse_json_metadata_info(
            source_id, service_data.get('metadata', {}))
        documentation = service_data.get('documentation')
        return ServiceInfo(name=service_name,
                           operations=operations,
                           structures=structures,
                           enumerations=enumerations,
                           constants=constants,
                           metadata=metadata,
                           documentation=documentation)

    def _parse_json_package_info(self, source_id, package_data):
        """
        Parse Package Info json object

        :type  source_id: :class:`str`
        :param source_id: Source metamodel
        :type  package_data: :class:`dict`
        :param package_data: Structure Info json object
        :rtype: :class:`com.vmware.vapi.metadata.metamodel_provider.PackageInfo`
        :return: PackageInfo object
        """
        name = package_data.get('name')
        structures = self._parse_json_structure_data(
            source_id, package_data.get('structures', []))
        enumerations = self._parse_json_enumeration_data(
            source_id, package_data.get('enumerations', []))
        services = {}
        for service_data in package_data.get('services', []):
            service_name = service_data.get('name')
            info = self._parse_json_service_info(source_id, service_data)
            self._maps.service_info[service_name] = info
            self._maps.service_mapping.setdefault(
                source_id, []).append(service_name)
            services[service_name] = info
        metadata = self._parse_json_metadata_info(
            source_id, package_data.get('metadata', {}))
        documentation = package_data.get('documentation')
        return PackageInfo(name=name,
                           structures=structures,
                           enumerations=enumerations,
                           services=services,
                           metadata=metadata,
                           documentation=documentation)

    def _parse_json_component_info(self, source_id, component_data):
        """
        Parse Component Info json object

        :type  source_id: :class:`str`
        :param source_id: Source metamodel
        :type  component_data: :class:`dict`
        :param component_data: Component Info json object
        :rtype:
            :class:`com.vmware.vapi.metadata.metamodel_provider.ComponentInfo`
        :return: ComponentInfo object
        """
        name = component_data.get('name')
        packages = {}
        for package_data in component_data.get('packages', []):
            package_name = package_data.get('name')
            info = self._parse_json_package_info(source_id, package_data)
            self._maps.package_info[package_name] = info
            self._maps.package_mapping.setdefault(
                source_id, []).append(package_name)
            packages[package_name] = info
        metadata = self._parse_json_metadata_info(
            source_id, component_data.get('metadata', {}))
        documentation = component_data.get('documentation')
        return ComponentInfo(name=name,
                             packages=packages,
                             metadata=metadata,
                             documentation=documentation)

    def _parse_json_metadata(self, source_id, idl_metadata):
        """
        Parse metadata obtained from a file

        :type  source_id: :class:`str`
        :param source_id: Source metamodel
        :type  idl_metadata: :class:`list` of :class:`dict`
        :param idl_metadata: metamodel metadata
        """
        if not idl_metadata:
            return

        component_data = idl_metadata.get('component')
        if not component_data:
            # For backward compatibility
            component_data = idl_metadata.get('product')

        component_name = component_data.get('name')

        component_info = self._parse_json_component_info(
            source_id, component_data)
        self._maps.component_info[component_name] = component_info

        self._maps.component_mapping.setdefault(source_id,
                                                []).append(component_name)

        fingerprint = self._generate_fingerprint(
            (component_name, component_info))
        self._maps.component_fingerprints[component_name] = fingerprint

    def _parse_remote_metadata_info(self, source_id, metadata):
        """
        Parse remote metadata

        :type  source_id: :class:`str`
        :param source_id: Source metamodel
        """
        if 'Resource' in metadata:
            elements = metadata['Resource'].elements
            if 'value' in elements:
                value = elements['value']
                if value.type == ElementValue.Type.STRING:
                    self._maps.resource_mapping.setdefault(
                        source_id, set()).add(value.string_value)
                elif value.type == ElementValue.Type.STRING_LIST:
                    self._maps.resource_mapping.setdefault(
                        source_id, set()).update(value.list_value)

    def _parse_remote_enumeration_data(self, source_id,
                                       enumeration_remote_data):
        """
        Parse remote EnumerationData

        :type  source_id: :class:`str`
        :param source_id: Source metamodel
        :type  enumeration_remote_data: :class:`dict` of :class:`str` and
            :class:`com.vmware.vapi.metadata.metamodel.EnumerationInfo`
        :param enumeration_remote_data: EnumerationData Map
        """
        for name, info in six.iteritems(enumeration_remote_data):
            self._maps.enumeration_info[name] = info
            self._maps.enumeration_mapping.setdefault(source_id,
                                                      []).append(name)

    def _parse_remote_structure_data(self, source_id, structure_remote_data):
        """
        Parse remote StructureData

        :type  source_id: :class:`str`
        :param source_id: Source metamodel
        :type  structure_remote_data: :class:`dict` of :class:`str` and
            :class:`com.vmware.vapi.metadata.metamodel.StructureInfo`
        :param structure_remote_data: StructureData Map
        """
        for name, info in six.iteritems(structure_remote_data):
            self._maps.structure_info[name] = info
            self._maps.structure_mapping.setdefault(source_id, []).append(name)
            self._parse_remote_enumeration_data(source_id, info.enumerations)
            for field in info.fields:
                self._parse_remote_metadata_info(source_id, field.metadata)
            self._process_model_info(name, info)

    def _parse_remote_service_info(self, source_id, service_name, service_info):
        """
        Parse ServiceInfo remote data

        :type  source_id: :class:`str`
        :param source_id: Source metamodel
        :type  service_name: :class:`str`
        :param service_name: Service Name
        :type  service_info: :class:`com.vmware.vapi.metadata
            .metamodel_provider.ServiceInfo`
        :param service_info: ServiceInfo object
        """
        self._parse_remote_structure_data(source_id, service_info.structures)
        self._parse_remote_enumeration_data(source_id,
                                            service_info.enumerations)
        for name, info in six.iteritems(service_info.operations):
            self._maps.operation_info[(service_name, name)] = info
            self._maps.operation_mapping.setdefault(source_id, []).append(
                (service_name, name))
            for param in info.params:
                self._parse_remote_metadata_info(source_id, param.metadata)
            self._parse_remote_metadata_info(source_id, info.output.metadata)

    def _parse_remote_package_info(self, source_id, package_info):
        """
        Parse PackageInfo remote data

        :type  source_id: :class:`str`
        :param source_id: Source metamodel
        :type  package_info: :class:`com.vmware.vapi.metadata
            .metamodel_provider.PackageInfo`
        :param package_info: PackageInfo object
        """
        self._parse_remote_structure_data(source_id, package_info.structures)
        self._parse_remote_enumeration_data(source_id,
                                            package_info.enumerations)
        for name, info in six.iteritems(package_info.services):
            self._parse_remote_service_info(source_id, name, info)
            self._maps.service_info[name] = info
            self._maps.service_mapping.setdefault(source_id, []).append(name)

    def _parse_remote_component_info(self, source_id, component_info):
        """
        Parse ComponentInfo remote data

        :type  source_id: :class:`str`
        :param source_id: Source metamodel
        :type  component_info: :class:`com.vmware.vapi.metadata
            .metamodel_provider.ComponentInfo`
        :param component_info: ComponentInfo object
        """
        for name, info in six.iteritems(component_info.packages):
            self._parse_remote_package_info(source_id, info)
            self._maps.package_info[name] = info
            self._maps.package_mapping.setdefault(source_id, []).append(name)

    def _parse_remote_metadata(self, source_id, stub_factory):
        """
        Parse metadata obtained from a remote source

        :type  source_id: :class:`str`
        :param source_id: Source metamodel
        :type  stub_factory: :class:`vmware.vapi.bindings.stub.StubFactory`
        :param stub_factory: Stub factory
        """
        if not stub_factory:
            return
        component_stub = stub_factory.create_stub(
            'com.vmware.vapi.metadata.metamodel.component')
        for component_id in component_stub.list():
            component_data = component_stub.get(component_id=component_id)
            self._parse_remote_component_info(source_id, component_data.info)
            self._maps.component_info[component_id] = component_data.info

            self._maps.component_mapping.setdefault(source_id,
                                                    []).append(component_id)
            self._maps.component_fingerprints[component_id] = \
                component_data.fingerprint


def register_instance(cfg):
    """
    Specify the instances that should be
    registered with the api provider

    :type  cfg: :class:`dict` of :class:`str` and :class:`str`
    :param cfg: Configuration for the service specified in the properties file
    """
    maps = get_metamodel_maps()
    return [
        EnumerationImpl(maps),
        OperationImpl(maps),
        PackageImpl(maps),
        ComponentImpl(maps),
        ServiceImpl(maps),
        SourceImpl(maps, cfg),
        StructureImpl(maps),
        ResourceImpl(maps),
        ModelImpl(maps),
    ]
